PACKAGE = "bicho"
VERSION = "0.9"

AUTHOR = "GSyC/LibreSoft, Universidad Rey Juan Carlos"
AUTHOR_EMAIL = "metrics-grimoire@lists.libresoft.es"
COPYRIGHT = "Copyright (C) 2007-2013 GSyC/LibreSoft, Universidad Rey Juan Carlos"
DESCRIPTION = "An analysis tool for issue tracking systems"
